import numpy as np
from sklearn.metrics import roc_curve, auc, average_precision_score


def evaluate(label_true, label_predict, dec_values, topN):
    pos_class = 1  # 1 as fraud label
    neg_class = 0  # 0 as non-fraud label

    assert len(label_true) == len(label_predict)
    assert len(label_true) == len(dec_values)

    results = {}

    # Calculate metric: AUC
    fpr, tpr, thresholds = roc_curve(label_true, dec_values, pos_label=pos_class)
    AUC = auc(fpr, tpr)
    results['auc'] = AUC

    # Calculate metric: AUC-PR
    AUC_PR = average_precision_score(label_true, dec_values)
    results['auc_pr'] = AUC_PR

    # Calculate metric: precision, sensitivity, specificity, and BAC (balanced accuracy) by using topN% cut-off thresh
    k = round(len(label_true) * topN)
    idx = np.argsort(dec_values)[::-1]
    label_predict_topk = np.full(len(label_true), neg_class)
    label_predict_topk[idx[:k]] = 1

    tp_topk = np.sum((label_true == pos_class) & (label_predict_topk == pos_class))
    fn_topk = np.sum((label_true == pos_class) & (label_predict_topk == neg_class))
    tn_topk = np.sum((label_true == neg_class) & (label_predict_topk == neg_class))
    fp_topk = np.sum((label_true == neg_class) & (label_predict_topk == pos_class))

    sensitivity_topk = tp_topk / (tp_topk + fn_topk)
    specificity_topk = tn_topk / (tn_topk + fp_topk)
    results['bac_topk'] = (sensitivity_topk + specificity_topk) / 2
    precision_topk = tp_topk / (tp_topk + fp_topk)
    results['sensitivity_topk'] = sensitivity_topk
    results['specificity_topk'] = specificity_topk
    results['precision_topk'] = precision_topk

    # Calculate metric: NDCG@k
    hits = np.sum(label_true == pos_class)
    kz = min(k, hits)
    z = 0.0

    for i in range(kz):
        rel = 1
        z += (2 ** rel - 1) / np.log2(1 + i + 1)

    dcg_at_k = 0.0

    for i in range(k):
        if label_true[idx[i]] == 1:
            rel = 1
            dcg_at_k += (2 ** rel - 1) / np.log2(1 + i + 1)

    if z != 0:
        ndcg_at_k = dcg_at_k / z
    else:
        ndcg_at_k = 0

    results['ndcg_at_k'] = ndcg_at_k

    return results
