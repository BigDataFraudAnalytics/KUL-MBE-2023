import numpy as np
import pandas as pd
from imblearn.ensemble import BalancedBaggingClassifier
from sklearn.tree import DecisionTreeClassifier
from data_reader import data_reader
from evaluate import evaluate
from sklearn.impute import SimpleImputer

output_file = "/Users/quinten/Desktop/UnderBagging(28 + 14 variables)/UnderBagging_Results (28 + 14 variables).txt"
with open(output_file, "w") as f:
    for year_test in range(2003, 2015):
        np.random.seed(0)
        print(
            f"==> Running UnderBagging (training period: 1991-{year_test - 2}, testing period: {year_test}, with 2-year gap)...",
            file=f)

        data_train = data_reader("/Users/quinten/Desktop/UnderBagging(28 + 14 variables)/data_FraudDetection_JAR2020.csv", "data_default", 1991, year_test - 2)
        y_train = data_train["labels"]
        X_train = data_train["features"]
        paaer_train = data_train["paaers"]

        data_test = data_reader("/Users/quinten/Desktop/UnderBagging(28 + 14 variables)/data_FraudDetection_JAR2020.csv", "data_default", year_test, year_test)
        y_test = data_test["labels"]
        X_test = data_test["features"]
        paaer_test = np.unique(data_test["paaers"][data_test["labels"] != 0])

        # Handle serial frauds using PAAER
        y_train[np.isin(paaer_train, paaer_test)] = 0

        # Impute missing values using the mean of the column
        imputer = SimpleImputer(strategy="mean")

        # Fit and transform the training data
        X_train_imputed = imputer.fit_transform(X_train)

        # Transform the testing data
        X_test_imputed = imputer.transform(X_test)

        # Train model
        t1 = pd.Timestamp.now()
        base_model = DecisionTreeClassifier(
            criterion='entropy',
            max_depth=23,
            max_features='log2',
            min_samples_leaf=1,
            min_samples_split=2,
            splitter='random',
            random_state=0)
        underbagging = BalancedBaggingClassifier(
            base_estimator=base_model,
            n_estimators=894,
            random_state=0,
            sampling_strategy=0.1,
            max_samples=1.0,
            max_features=33)
        underbagging.fit(X_train_imputed, y_train)
        t_train = pd.Timestamp.now() - t1

        # Test model
        t2 = pd.Timestamp.now()
        label_predict = underbagging.predict(X_test_imputed)
        dec_values = underbagging.predict_proba(X_test_imputed)[:, 1]
        t_test = pd.Timestamp.now() - t2

        # Print performance results
        print(f"Training time: {t_train.total_seconds()} seconds | Testing time {t_test.total_seconds()} seconds",
              file=f)
        for topN in [0.01, 0.02, 0.03, 0.04, 0.05]:
            metrics = evaluate(y_test, label_predict, dec_values, topN)
            print(f"Performance (top{topN * 100}% as cut-off thresh):", file=f)
            print(f"AUC-ROC: {metrics['auc']:.4f}", file=f)
            print(f"AUC-PR: {metrics['auc_pr']:.4f}", file=f)
            print(f"NCDG@k: {metrics['ndcg_at_k']:.4f}", file=f)
            print(f"Sensitivity: {metrics['sensitivity_topk'] * 100:.2f}%", file=f)
            print(f"Precision: {metrics['precision_topk'] * 100:.2f}%", file=f)

            # Identify number of True Fraud cases using NDCG@k 1% cutoff approach
            if topN == 0.01:
                true_positives = int(metrics['sensitivity_topk'] * sum(y_test))
                print(f"Number of True Fraud Observations Identified (NDCG@1%): {true_positives}", file=f)
