import numpy as np


def data_reader(data_path, data_format, year_start, year_end):
    temp = np.genfromtxt(data_path, delimiter=',', skip_header=1)
    data = {}

    if data_format == 'data_default':  # read data with 28 raw accounting variables
        data['years'] = temp[:, 0]
        idx = (data['years'] >= year_start) & (data['years'] <= year_end)
        data['years'] = temp[idx, 0]
        data['firms'] = temp[idx, 1]
        data['paaers'] = temp[idx, 2]
        data['labels'] = temp[idx, 3]
        data['features'] = temp[idx, 4:46]
        data['num_observations'] = data['features'].shape[0]
        data['num_features'] = data['features'].shape[1]
    else:
        print('Error: unsupported data format!')

    print(f"Data Loaded: {data_path}, {data['num_features']} features, {data['num_observations']} observations.")
    return data
