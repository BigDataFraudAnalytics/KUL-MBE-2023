import numpy as np
from sklearn.metrics import average_precision_score, make_scorer
from imblearn.ensemble import BalancedBaggingClassifier
from sklearn.tree import DecisionTreeClassifier
from data_reader import data_reader
from skopt import BayesSearchCV
from skopt.space import Real, Integer, Categorical
from sklearn.impute import SimpleImputer

year_valid = 2001

np.random.seed(0)

data_train = data_reader("data_FraudDetection_JAR2020.csv", "data_default", 1991, year_valid - 2)
y_train = data_train["labels"]
X_train = data_train["features"]
paaer_train = data_train["paaers"]

data_valid = data_reader("data_FraudDetection_JAR2020.csv", "data_default", year_valid, year_valid)
y_valid = data_valid["labels"]
X_valid = data_valid["features"]
paaer_valid = np.unique(data_valid["paaers"][data_valid["labels"] != 0])

y_train[np.isin(paaer_train, paaer_valid)] = 0

# Impute missing values using the mean of the column
imputer = SimpleImputer(strategy="mean")

# Fit and transform the training data
X_train_imputed = imputer.fit_transform(X_train)

# Transform the validation data
X_valid_imputed = imputer.transform(X_valid)

base_model = DecisionTreeClassifier(random_state=0)
underbagging = BalancedBaggingClassifier(base_estimator=base_model, n_estimators=300, random_state=0)

search_space = {
    "n_estimators": Integer(20, 1000),
    "base_estimator__criterion": Categorical(["gini", "entropy"]),
    "base_estimator__splitter": Categorical(["best", "random"]),
    "base_estimator__min_samples_leaf": Integer(1, 100),
    "base_estimator__max_depth": Categorical([None] + list(range(1, 51))),
    "base_estimator__min_samples_split": Integer(2, 50),
    "base_estimator__max_features": Categorical(["auto", "sqrt", "log2"]),
    "sampling_strategy": Real(0.1, 1.0),
    "max_samples": Real(0.1, 1.0),
    "max_features": Integer(1, X_train.shape[1])
}

auc_pr_scorer = make_scorer(average_precision_score, greater_is_better=True, needs_proba=True)

bayes_search = BayesSearchCV(
    underbagging,
    search_space,
    scoring=auc_pr_scorer,
    n_iter=50,
    cv=5,
    n_jobs=-1,
    random_state=0
)

bayes_search.fit(X_train_imputed, y_train)

best_params = bayes_search.best_params_
print(f"Best Parameters: {best_params}")

best_model = bayes_search.best_estimator_
label_predict = best_model.predict(X_valid_imputed)
dec_values = best_model.predict_proba(X_valid_imputed)[:, 1]

auc_pr = average_precision_score(y_valid, dec_values)
print(f"AUC-PR: {auc_pr:.4f}")
