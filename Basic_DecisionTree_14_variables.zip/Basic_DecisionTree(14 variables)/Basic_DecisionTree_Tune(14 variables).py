# Import necessary libraries and modules
import numpy as np
from sklearn.metrics import average_precision_score, make_scorer
from sklearn.tree import DecisionTreeClassifier
from sklearn.impute import SimpleImputer
from data_reader import data_reader
from skopt import BayesSearchCV
from skopt.space import Integer, Categorical, Real

# Set the validation year
year_valid = 2001

# Set the random seed to ensure reproducibility
np.random.seed(0)

# Load training data
data_train = data_reader("/Users/quinten/Desktop/Basic_DecisionTree(14 variables)/data_FraudDetection_JAR2020.csv", "data_default", 1991, year_valid - 2)
y_train = data_train["labels"]
X_train = data_train["features"]
paaer_train = data_train["paaers"]

# Load validation data
data_valid = data_reader("/Users/quinten/Desktop/Basic_DecisionTree(14 variables)/data_FraudDetection_JAR2020.csv", "data_default", year_valid, year_valid)
y_valid = data_valid["labels"]
X_valid = data_valid["features"]
paaer_valid = np.unique(data_valid["paaers"][data_valid["labels"] != 0])

y_train[np.isin(paaer_train, paaer_valid)] = 0

# Impute missing values with mean
imputer = SimpleImputer(strategy='mean')
X_train = imputer.fit_transform(X_train)
X_valid = imputer.transform(X_valid)

# Instantiate a DecisionTreeClassifier with a fixed random state
dt = DecisionTreeClassifier(random_state=0)

# Define the search space for hyperparameters
search_space = {
    "criterion": Categorical(["gini", "entropy"]),
    "splitter": Categorical(["best", "random"]),
    "max_depth": Categorical([None] + list(range(1, 51))),
    "min_samples_split": Integer(2, 50),
    "min_samples_leaf": Integer(1, 100),
    "max_features": Categorical(["auto", "sqrt", "log2"]),
}

# Create a scoring function for AUC-PR
auc_pr_scorer = make_scorer(average_precision_score, greater_is_better=True, needs_proba=True)

# Initialize BayesSearchCV with the DecisionTreeClassifier, search space, scoring function, and other settings
bayes_search = BayesSearchCV(
    dt,
    search_space,
    scoring=auc_pr_scorer,
    n_iter=100,
    cv=5,
    n_jobs=-1,
    random_state=0
)

# Perform hyperparameter optimization with Bayesian Optimization
bayes_search.fit(X_train, y_train)

# Print the best hyperparameters found by BayesSearchCV
best_params = bayes_search.best_params_
print(f"Best Parameters: {best_params}")

# Make predictions on the validation set using the best model
best_model = bayes_search.best_estimator_
label_predict = best_model.predict(X_valid)
dec_values = best_model.predict_proba(X_valid)[:, 1]

# Calculate the AUC-PR score for the best model
auc_pr = average_precision_score(y_valid, dec_values)
print(f"AUC-PR: {auc_pr:.4f}")
