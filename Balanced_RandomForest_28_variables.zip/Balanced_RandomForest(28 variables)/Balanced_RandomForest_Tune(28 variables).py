# Import necessary libraries and modules
import numpy as np
from sklearn.metrics import average_precision_score, make_scorer
from imblearn.ensemble import BalancedRandomForestClassifier
from data_reader import data_reader
from skopt import BayesSearchCV
from skopt.space import Real, Integer, Categorical
# Set the validation year
year_valid = 2001
# Set random seed for reproducibility
np.random.seed(0)
# Read training data using data_reader function
data_train = data_reader("data_FraudDetection_JAR2020.csv", "data_default", 1991, year_valid - 2)
y_train = data_train["labels"]
X_train = data_train["features"]
paaer_train = data_train["paaers"]
# Read validation data using data_reader function
data_valid = data_reader("data_FraudDetection_JAR2020.csv", "data_default", year_valid, year_valid)
y_valid = data_valid["labels"]
X_valid = data_valid["features"]
# Handle serial frauds using PAAER
paaer_valid = np.unique(data_valid["paaers"][data_valid["labels"] != 0])
# Handle serial frauds using PAAER
y_train[np.isin(paaer_train, paaer_valid)] = 0
# Initialize model
brf = BalancedRandomForestClassifier(random_state=0)
# Define search space for Bayesian optimization
search_space = {
    "n_estimators": Integer(20, 1000),
    "min_samples_leaf": Integer(1, 100),
    "max_depth": Categorical([None] + list(range(1, 51))),
    "sampling_strategy": Real(0.1, 1.0),
    "max_features": Categorical(["auto", "sqrt", "log2"]),
    "min_samples_split": Integer(2, 50),
    "criterion": Categorical(["gini", "entropy"]),
}
# Create AUC-PR scorer for model evaluation
auc_pr_scorer = make_scorer(average_precision_score, greater_is_better=True, needs_proba=True)
# Initialize BayesSearchCV for hyperparameter tuning using Bayesian optimization
bayes_search = BayesSearchCV(
    brf,
    search_space,
    scoring=auc_pr_scorer,
    n_iter=100,
    cv=5,
    n_jobs=-1,
    random_state=0
)
# Fit the BayesSearchCV to the training data
bayes_search.fit(X_train, y_train)
# Print the best hyperparameters
best_params = bayes_search.best_params_
print(f"Best Parameters: {best_params}")
# Get the best model and make predictions on the validation set
best_model = bayes_search.best_estimator_
label_predict = best_model.predict(X_valid)
dec_values = best_model.predict_proba(X_valid)[:, 1]
# Compute the AUC-PR metric for the best model
auc_pr = average_precision_score(y_valid, dec_values)
print(f"AUC-PR: {auc_pr:.4f}")
