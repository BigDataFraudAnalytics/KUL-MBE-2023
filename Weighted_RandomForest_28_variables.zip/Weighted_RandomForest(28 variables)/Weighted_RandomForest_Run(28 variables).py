# Import necessary libraries and modules
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from data_reader import data_reader
from evaluate import evaluate
# Set output file path
output_file = "Weighted_RandomForest_Results(28 variables).txt"
# Open the output file for writing results
with open(output_file, "w") as f:
    # Iterate through test years (2003 to 2014)
    for year_test in range(2003, 2015):
        # Set random seed for reproducibility
        np.random.seed(0)
        # Print progress message to output file
        print(
            f"==> Running WeightedRandomForest (training period: 1991-{year_test - 2}, testing period: {year_test}, with 2-year gap)...",
            file=f)
        # Read training data using data_reader function
        data_train = data_reader("data_FraudDetection_JAR2020.csv", "data_default", 1991, year_test - 2)
        y_train = data_train["labels"]
        X_train = data_train["features"]
        paaer_train = data_train["paaers"]
        # Read testing data using data_reader function
        data_test = data_reader("data_FraudDetection_JAR2020.csv", "data_default", year_test, year_test)
        y_test = data_test["labels"]
        X_test = data_test["features"]
        # Handle serial frauds using PAAER
        paaer_test = np.unique(data_test["paaers"][data_test["labels"] != 0])

        # Handle serial frauds using PAAER
        y_train[np.isin(paaer_train, paaer_test)] = 0

        # Train model
        t1 = pd.Timestamp.now()
        weighted_rf = RandomForestClassifier(n_estimators=1000, criterion='entropy', max_depth=30, max_features='auto', max_leaf_nodes=100, min_samples_leaf=43, min_samples_split=46, min_impurity_decrease=0.0, random_state=0, class_weight='balanced', n_jobs=-1)
        weighted_rf.fit(X_train, y_train)
        t_train = pd.Timestamp.now() - t1

        # Test model
        t2 = pd.Timestamp.now()
        label_predict = weighted_rf.predict(X_test)
        dec_values = weighted_rf.predict_proba(X_test)[:, 1]
        t_test = pd.Timestamp.now() - t2

        # Print performance results for different cutoffs
        print(f"Training time: {t_train.total_seconds()} seconds | Testing time {t_test.total_seconds()} seconds",
              file=f)
        for topN in [0.01, 0.02, 0.03, 0.04, 0.05]:
            metrics = evaluate(y_test, label_predict, dec_values, topN)
            print(f"Performance (top{topN * 100}% as cut-off thresh):", file=f)
            print(f"AUC-ROC: {metrics['auc']:.4f}", file=f)
            print(f"AUC-PR: {metrics['auc_pr']:.4f}", file=f)
            print(f"NCDG@k: {metrics['ndcg_at_k']:.4f}", file=f)
            print(f"Sensitivity: {metrics['sensitivity_topk'] * 100:.2f}%", file=f)
            print(f"Precision: {metrics['precision_topk'] * 100:.2f}%", file=f)

            # Identify number of True Fraud cases using NDCG@k 1% cutoff approach
            if topN == 0.01:
                true_positives = int(metrics['sensitivity_topk'] * sum(y_test))
                print(f"Number of True Fraud Observations Identified (NDCG@1%): {true_positives}", file=f)