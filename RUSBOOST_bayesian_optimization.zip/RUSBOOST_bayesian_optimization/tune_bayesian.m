diary("tune_rusboost_bayesianoptimization.txt");
year_valid = 2001;

rng(0,'twister'); % fix random seed for reproducing the results

% read training data
data_train = data_reader('data_FraudDetection_JAR2020.csv', 'data_default', 1991, year_valid-2);
y_train = data_train.labels;
X_train = data_train.features;
paaer_train = data_train.paaers;

% read validating data
data_valid = data_reader('data_FraudDetection_JAR2020.csv', 'data_default', year_valid, year_valid);
y_valid = data_valid.labels;
X_valid = data_valid.features;
paaer_valid = unique(data_valid.paaers(data_valid.labels~=0));

% handle serial frauds using PAAER
y_train(ismember(paaer_train,paaer_valid)) = 0;

% Create an objective function
objective = @(params) rusboost_objective(params, X_train, y_train, X_valid, y_valid);

% Set the parameter space for the optimization
param_space = [
    optimizableVariable('NumTrees', [100, 3000], 'Type', 'integer')
    optimizableVariable('LearnRate', [0.01, 0.5], 'Transform', 'log')
    optimizableVariable('MinLeafSize', [1, 20], 'Type', 'integer')
    optimizableVariable('RatioToSmallest', [1, 10], 'Type', 'integer')];

% Perform the Bayesian optimization
results = bayesopt(objective, param_space, 'MaxObjectiveEvaluations', 50, 'IsObjectiveDeterministic', false, 'AcquisitionFunctionName', 'expected-improvement-plus');

% Display the best hyperparameters found by the optimization
best_params = results.XAtMinObjective;

% Print the results
fprintf('Best Hyperparameters:\n');
fprintf('NumTrees: %d\n', best_params.NumTrees);
fprintf('LearnRate: %.4f\n', best_params.LearnRate);
fprintf('MinLeafSize: %d\n', best_params.MinLeafSize);
fprintf('RatioToSmallest: %d\n', best_params.RatioToSmallest);

% rusboost_objective function
function auc = rusboost_objective(params, X_train, y_train, X_valid, y_valid)
    t = templateTree('MinLeafSize', params.MinLeafSize); % base model
    rusboost = fitensemble(X_train, y_train, 'RUSBoost', params.NumTrees, t, 'LearnRate', params.LearnRate, 'RatioToSmallest', [1 params.RatioToSmallest]);
    [label_predict, dec_values] = predict(rusboost, X_valid);
    dec_values = dec_values(:, 2);
    [~, ~, ~, auc] = perfcurve(y_valid, dec_values, 1, 'xCrit', 'reca', 'yCrit', 'prec');
    auc = -auc; % minimize -auc, maximize auc
end
